# web-basic
Una página web con HTML5 y CSS3
Se ha adaptado a todo tamaño de pantalla
Se ha aplicado Bootstrap
Se ha generado el git local
Se ha enlazado con el github remoto
Se ha aplicado SASS
# SASS
